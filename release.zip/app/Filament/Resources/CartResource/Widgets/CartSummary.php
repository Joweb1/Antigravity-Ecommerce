<?php

namespace App\Filament\Resources\CartResource\Widgets;

use Filament\Widgets\StatsOverviewWidget as BaseWidget;
use Filament\Widgets\StatsOverviewWidget\Stat;

class CartSummary extends BaseWidget
{
    protected function getStats(): array
    {
        return [
            //
        ];
    }
}
